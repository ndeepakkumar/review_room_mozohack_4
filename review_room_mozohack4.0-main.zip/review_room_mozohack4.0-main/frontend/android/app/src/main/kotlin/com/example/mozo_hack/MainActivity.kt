package com.example.mozo_hack

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
